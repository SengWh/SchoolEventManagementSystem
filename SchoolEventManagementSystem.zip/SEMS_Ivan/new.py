from flask import Flask, render_template, request, abort, jsonify, redirect, url_for
import pymysql
from datetime import date

app = Flask(__name__)

conn = pymysql.connect(host="localhost", user="root", passwd="", db="eventmanagement")

@app.route('/')
def log_in():
    return render_template("log_in.html")

@app.route('/',methods=['POST'])
def run():
    error = None
    # username = request.form['username']
    # password = request.form['password']
    # if request.form['password'] == "":
    #     error = "Invalid Password!"
    #     return render_template("log_in.html",error = error)
    # else:
    #     return render_template('student_main.html', username=username)

    username = request.form['username']
    password = request.form['password']
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM USER WHERE user.USER_ID = %s AND user.USER_PASSWORD = %s", (username, password))
    account = cursor.fetchone()

    if account:
        cursor2 = conn.cursor()
        cursor2.execute("SELECT USER.USER_NAME FROM USER WHERE USER.USER_ID = %s", username)
        user = cursor2.fetchone()
        return render_template("student_main.html",username= user[0],id = username )
    else:
        error = "Invalid Credentials! Please Try Again!"
        return render_template("log_in.html",error=error)



@app.route('/main')
def student_main():
    return render_template('student_main.html')

@app.route('/view-event-calendar')
def view_event_calendar():
    e1 = ""
    e2 = ''
    e3 = ''
    e4 = ''
    e5 = ''
    e6 = ''
    e7 = ''
    e8 = ''
    e9 = ''
    e10 = ''
    e11 = ''
    e12 = ''
    e13 = ''
    e14 = ''
    e15 = ''
    e16 = ''
    e17 = ''
    e18 = ''
    e19 = ''
    e20 = ''
    e21 = ''
    e22 = ''
    e23 = ''
    e24 = ''
    e25 = ''
    e26 = ''
    e27 = ''
    e28 = ''
    e29 = ''
    e30 = ''
    e31 = ''

    today = date.today()
    cursor3 = conn.cursor()
    cursor3.execute("SELECT EVENT.EVENT_NAME, EVENT.EVENT_START_DATE FROM EVENT WHERE EVENT.EVENT_START_DATE >%s",(today))
    events = cursor3.fetchall()
    print(events)
    for i in range(len(events)):
        if events[i][1].day == 1:
            e1 = events[i][0]
        if events[i][1].day == 2:
            e2 = events[i][0]
        if events[i][1].day == 3:
            e3 = events[i][0]
        if events[i][1].day == 4:
            e4 = events[i][0]
        if events[i][1].day == 5:
            e5 = events[i][0]
        if events[i][1].day == 6:
            e6 = events[i][0]
        if events[i][1].day == 7:
            e7 = events[i][0]
        if events[i][1].day == 8:
            e8 = events[i][0]
        if events[i][1].day == 9:
            e9 = events[i][0]
        if events[i][1].day == 10:
            e10 = events[i][0]
        if events[i][1].day == 11:
            e11 = events[i][0]
        if events[i][1].day == 12:
            e12 = events[i][0]
        if events[i][1].day == 13:
            e13 = events[i][0]
        if events[i][1].day == 14:
            e14 = events[i][0]
        if events[i][1].day == 15:
            e15 = events[i][0]
        if events[i][1].day == 16:
            e16 = events[i][0]
        if events[i][1].day == 17:
            e17 = events[i][0]
        if events[i][1].day == 18:
            e18 = events[i][0]
        if events[i][1].day == 19:
            e19 = events[i][0]
        if events[i][1].day == 20:
            e20 = events[i][0]
        if events[i][1].day == 20:
            e20 = events[i][0]
        if events[i][1].day == 21:
            e21 = events[i][0]
        if events[i][1].day == 22:
            e22 = events[i][0]
        if events[i][1].day == 23:
            e23 = events[i][0]
        if events[i][1].day == 24:
            e24 = events[i][0]
        if events[i][1].day == 25:
            e25 = events[i][0]
        if events[i][1].day == 26:
            e26 = events[i][0]
        if events[i][1].day == 27:
            e27 = events[i][0]
        if events[i][1].day == 28:
            e28 = events[i][0]
        if events[i][1].day == 29:
            e29 = events[i][0]
        if events[i][1].day == 30:
            e30 = events[i][0]
        if events[i][1].day == 31:
            e31 = events[i][0]



    return render_template('view_event_calendar.html',e1=e1,e2=e2,e3=e3,e4=e4,e5=e5,
                           e6=e6,e7=e7,e8=e8,e9=e9,e10=e10,e11=e11,e12=e12,e13=e13,e14=e14,
                           e15=e15,e16=e16,e17=e17,e18=e18,e19=e19,e20=e20,e21=e21,e22=e22,
                           e23=e23,e24=e24,e25=e25,e26=e26,e27=e27,e28=e28,e29=e29,e30=e30,
                           e31=e31)

@app.route('/view-event-calendar',methods=['POST'])
def review_event_calendar():
    today = date.today()
    cursor4 = conn.cursor()
    cursor4.execute("SELECT * FROM EVENT WHERE EVENT.EVENT_START_DATE >%s", (today))
    events2 = cursor4.fetchall()
    print(events2)


    Error = None;
    eventdate = request.form['eventdate']
    eventname = request.form['eventname']

    for i in range(len(events2)):
        if events2[i][1]==eventname and events2[i][4].strftime('%Y-%m-%d')==eventdate:
            return render_template('event_details.html', eventdate=eventdate, eventname=eventname)
        else:
            Error = "Date or Event does not exist!"









    e1 = ""
    e2 = ''
    e3 = ''
    e4 = ''
    e5 = ''
    e6 = ''
    e7 = ''
    e8 = ''
    e9 = ''
    e10 = ''
    e11 = ''
    e12 = ''
    e13 = ''
    e14 = ''
    e15 = ''
    e16 = ''
    e17 = ''
    e18 = ''
    e19 = ''
    e20 = ''
    e21 = ''
    e22 = ''
    e23 = ''
    e24 = ''
    e25 = ''
    e26 = ''
    e27 = ''
    e28 = ''
    e29 = ''
    e30 = ''
    e31 = ''

    today = date.today()
    cursor3 = conn.cursor()
    cursor3.execute("SELECT EVENT.EVENT_NAME, EVENT.EVENT_START_DATE FROM EVENT WHERE EVENT.EVENT_START_DATE >%s",(today))
    events = cursor3.fetchall()
    for i in range(len(events)):
        if events[i][1].day == 1:
            e1 = events[i][0]
        if events[i][1].day == 2:
            e2 = events[i][0]
        if events[i][1].day == 3:
            e3 = events[i][0]
        if events[i][1].day == 4:
            e4 = events[i][0]
        if events[i][1].day == 5:
            e5 = events[i][0]
        if events[i][1].day == 6:
            e6 = events[i][0]
        if events[i][1].day == 7:
            e7 = events[i][0]
        if events[i][1].day == 8:
            e8 = events[i][0]
        if events[i][1].day == 9:
            e9 = events[i][0]
        if events[i][1].day == 10:
            e10 = events[i][0]
        if events[i][1].day == 11:
            e11 = events[i][0]
        if events[i][1].day == 12:
            e12 = events[i][0]
        if events[i][1].day == 13:
            e13 = events[i][0]
        if events[i][1].day == 14:
            e14 = events[i][0]
        if events[i][1].day == 15:
            e15 = events[i][0]
        if events[i][1].day == 16:
            e16 = events[i][0]
        if events[i][1].day == 17:
            e17 = events[i][0]
        if events[i][1].day == 18:
            e18 = events[i][0]
        if events[i][1].day == 19:
            e19 = events[i][0]
        if events[i][1].day == 20:
            e20 = events[i][0]
        if events[i][1].day == 20:
            e20 = events[i][0]
        if events[i][1].day == 21:
            e21 = events[i][0]
        if events[i][1].day == 22:
            e22 = events[i][0]
        if events[i][1].day == 23:
            e23 = events[i][0]
        if events[i][1].day == 24:
            e24 = events[i][0]
        if events[i][1].day == 25:
            e25 = events[i][0]
        if events[i][1].day == 26:
            e26 = events[i][0]
        if events[i][1].day == 27:
            e27 = events[i][0]
        if events[i][1].day == 28:
            e28 = events[i][0]
        if events[i][1].day == 29:
            e29 = events[i][0]
        if events[i][1].day == 30:
            e30 = events[i][0]
        if events[i][1].day == 31:
            e31 = events[i][0]



    return render_template('view_event_calendar.html',e1=e1,e2=e2,e3=e3,e4=e4,e5=e5,
                           e6=e6,e7=e7,e8=e8,e9=e9,e10=e10,e11=e11,e12=e12,e13=e13,e14=e14,
                           e15=e15,e16=e16,e17=e17,e18=e18,e19=e19,e20=e20,e21=e21,e22=e22,
                           e23=e23,e24=e24,e25=e25,e26=e26,e27=e27,e28=e28,e29=e29,e30=e30,
                           e31=e31, Error = Error )

@app.route('/attendance-taking')
def attendance_taking():
    return render_template('attendance_taking.html')

@app.route('/event_details')
def event_details():
    return render_template('event_details.html')


@app.route('/event-history')
def event_history():
    e1= ""
    e2= ''
    e3= ''
    e4=''
    e5=''
    d1=''
    d2=''
    d3=''
    d4=''
    d5=''
    today = date.today()
    cursor3 = conn.cursor()
    cursor3.execute("SELECT EVENT_NAME, EVENT_START_DATE FROM EVENT,EVENT_STUDENT WHERE EVENT.EVENT_ID = EVENT_STUDENT.EVENT_ID AND EVENT_START_DATE<%s",
                    (today))
    events = cursor3.fetchall()
    for i in range(len(events)):
        if i == 0:
            e1 = events[i][0]
            d1 = events[i][1]
        if i == 1:
            e2 = events[i][0]
            d2 = events[i][1]
        if i == 2:
            e3 = events[i][0]
            d3 = events[i][1]
        if i == 3:
            e4 = events[i][0]
            d4 = events[i][1]
        if i == 4:
            e5 = events[i][0]
            d5 = events[i][1]




    return render_template('event_history.html',e1=e1,e2=e2,e3=e3,e4=e4,e5=e5,d1=d1,d2=d2,d3=d3,d4=d4,d5=d5)

if __name__ == "__main__":
    app.run(debug=True)